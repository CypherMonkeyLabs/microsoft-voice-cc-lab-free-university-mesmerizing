/* Offline cache for the Voice Lab. Generated. Cache bf055806f02b. */
"use strict";
const CACHE = "mvcc-lab-bf055806f02b";
const PRECACHE = [
  "./",
  "./index.html",
  "./app.css",
  "./app.js",
  "./studios/topology.js",
  "./studios/hero.js",
  "./studios/icons.js",
  "./data/headings.json",
  "./vendor/postprocessing/EffectComposer.js",
  "./vendor/postprocessing/RenderPass.js",
  "./vendor/postprocessing/ShaderPass.js",
  "./vendor/postprocessing/MaskPass.js",
  "./vendor/postprocessing/Pass.js",
  "./vendor/postprocessing/UnrealBloomPass.js",
  "./vendor/shaders/CopyShader.js",
  "./vendor/shaders/LuminosityHighPassShader.js",
  "./vendor/three.module.min.js",
  "./vendor/OrbitControls.js",
  "./og-card.png",
  "./data/manifest.json",
  "./data/quiz.json",
  "./data/cards.json",
  "./data/glossary.json",
  "./data/charts.json",
  "./data/bosses.json",
  "./data/atlas.json",
  "./effects.js",
  "./guide.js",
  "./studios/pixel.js",
  "./data/guide.json",
  "./favicon.svg",
  "./favicon.ico",
  "./vendor/anime.esm.min.js",
  "./vendor/rough.esm.js",
  "./vendor/d3.min.js",
  "./vendor/confetti.browser.js",
  "./data/tracks/t01.json",
  "./data/tracks/t02.json",
  "./data/tracks/t03.json",
  "./data/tracks/t04.json",
  "./data/tracks/t05.json",
  "./data/tracks/t06.json",
  "./data/tracks/t07.json",
  "./data/tracks/t08.json",
  "./data/tracks/t09.json",
  "./data/tracks/t10.json",
  "./data/tracks/t11.json",
  "./data/tracks/t12.json",
  "./data/tracks/t13.json",
  "./data/tracks/t14.json",
  "./data/tracks/t15.json",
  "./data/tracks/t16.json",
  "./data/tracks/t17.json",
  "./audio/aa-goodbye.wav",
  "./audio/aa-hold.wav",
  "./audio/aa-hours.wav",
  "./audio/aa-operator.wav",
  "./audio/aa-record.wav",
  "./audio/aa-sales.wav",
  "./audio/aa-support.wav",
  "./audio/aa-welcome.wav",
  "./audio/dtmf-0.wav",
  "./audio/dtmf-1.wav",
  "./audio/dtmf-2.wav",
  "./audio/dtmf-3.wav",
  "./audio/dtmf-4.wav",
  "./audio/dtmf-5.wav",
  "./audio/dtmf-6.wav",
  "./audio/dtmf-7.wav",
  "./audio/dtmf-8.wav",
  "./audio/dtmf-9.wav",
  "./audio/dtmf-pound.wav",
  "./audio/dtmf-star.wav",
  "./audio/intro-cc.wav",
  "./audio/intro-emergency.wav",
  "./audio/intro-exams.wav",
  "./audio/intro-qos.wav",
  "./audio/intro-queue.wav",
  "./audio/intro-record.wav",
  "./audio/intro-routing.wav",
  "./audio/intro-tenant.wav",
  "./audio/tone-busy.wav",
  "./audio/tone-dial.wav",
  "./audio/tone-reorder.wav",
  "./audio/tone-ringback.wav",
  "./audio/architect-share.mp3",
  "./audio/architect-use.mp3",
  "./downloads/call-flows.html",
  "./downloads/career.html",
  "./downloads/catalog.json",
  "./downloads/config-checklist.html",
  "./downloads/flashcards.html",
  "./downloads/flashcards.json",
  "./downloads/glossary-core.html",
  "./downloads/glossary-full.html",
  "./downloads/migration.html",
  "./downloads/ports-protocols.html",
  "./downloads/track-t01.html",
  "./downloads/track-t02.html",
  "./downloads/track-t03.html",
  "./downloads/track-t04.html",
  "./downloads/track-t05.html",
  "./downloads/track-t06.html",
  "./downloads/track-t07.html",
  "./downloads/track-t08.html",
  "./downloads/track-t09.html",
  "./downloads/track-t10.html",
  "./downloads/track-t11.html",
  "./downloads/track-t12.html",
  "./downloads/track-t13.html",
  "./downloads/track-t14.html",
  "./downloads/track-t15.html",
  "./downloads/track-t16.html",
  "./downloads/track-t17.html",
  "./downloads/troubleshooting.html",
  "./downloads/whats-new.html"
];
self.addEventListener("install", function (event) {
  event.waitUntil(caches.open(CACHE).then(function (cache) { return cache.addAll(PRECACHE); }).then(function () { return self.skipWaiting(); }));
});
self.addEventListener("activate", function (event) {
  event.waitUntil(caches.keys().then(function (keys) {
    return Promise.all(keys.filter(function (key) { return key !== CACHE; }).map(function (key) { return caches.delete(key); }));
  }).then(function () { return self.clients.claim(); }));
});
self.addEventListener("fetch", function (event) {
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin || event.request.method !== "GET") return;
  event.respondWith(caches.match(event.request).then(function (cached) {
    const fetched = fetch(event.request).then(function (response) {
      if (response && response.ok) {
        const copy = response.clone();
        caches.open(CACHE).then(function (cache) { cache.put(event.request, copy); });
      }
      return response;
    }).catch(function () { return cached || caches.match("./index.html"); });
    return cached || fetched;
  }));
});
